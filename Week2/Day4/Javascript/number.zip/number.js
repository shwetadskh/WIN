console.log("For loop that will iterate from 0 to 100 for odd no/ even no /'0' no");


for (var n=0; n<100; n++) {
    if (n === 0) {
            console.log(n +  " is even");
    }
    else if (n % 2 == 0) {
            console.log(n + " is even");   
    }
    else {
            console.log(n + " is odd");
    }
}
